# yolo2 > 2023-03-03 1:52am
https://universe.roboflow.com/detectron2-2awod/yolo2-cd0ku

Provided by a Roboflow user
License: CC BY 4.0

